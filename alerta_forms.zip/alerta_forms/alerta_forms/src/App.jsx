import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './style.css'

function App() {

  return (
    <>
      <body>
        <div class = "principal">
          <h2> Cadastro</h2>
      <form action="#">
      <div class = "campo">
        <input id = "nome" type="text" placeholder='Digite seu nome' required />
      </div>
      <div class = "campo">
        <input id = "email" type="text" placeholder='Digite seu email' required />
      </div>
      <div class = "campo">
        <input id = "data" type="date" placeholder='Digite a data de nascimento' required />
      </div>
      <div class= "termos">
        <input type="checkbox" id="checar"/>
        <label htmlFor="checar">Aceitar os termos e políticas</label>
      </div>

      <div class = "campo">
        <button type= "button" onClick = {() => alerta(document, window)} > Cadastrar </button>
      </div> 

      </form>
      </div>
      </body>
    </>
  )
}
function alerta(documento, tela){
  const nome = documento.querySelector("#nome").value;
  const email = documento.querySelector("#email").value;
  const data = documento.querySelector("#data").value;

  console.log(data)

  if(nome == ""  ||email == ""  ||data == ""){
    tela.alert("Por favor preencha todos os dados")
    return;
  }

  tela.alert(`Olá ${nome}, seu email é ${email} e sua data de nascimento é ${data}`);
}


export default App
