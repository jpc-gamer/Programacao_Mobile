import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './app.css'




function App() {
  return (
    <>
      <body>
        <div class = "borda">
        <form action = ""> 
        <div class = "titulo">
          <h1> Faça o seu login </h1>
        <div class = "barra_horizontal"></div>
        </div>

        <div class = "campo_input">
          <label For="email"> Seu e-mail*</label>
          <input type="email" id="email"required/>
        </div>

        <div class = "campo_input">
          <label For="senha"> Sua senha* </label>
          <input type="senha" id="senha" required/>
        </div>

        <div class = "lembrar">
          <input type="checkbox"/>
          <p>Lembrar-me</p>
        </div>

        <button>Entrar</button>

        <p>
          Esqueceu a senha?
          <a href="#"> Clique aqui </a>
        </p>
        </form>
        </div>
      </body>
    </>
  )
}

export default App
