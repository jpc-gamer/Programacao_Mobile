import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './app.css'
import imagemA from './img/capitaoAmerica.jpg'
import imagemB from './img/huNk.jpg'
import imagemC from './img/homemAranha.jpg'
import imagemD from './img/homemFerro.jpg'
import imagemE from './img/OI.jpg'



function App() {
  return (
    <>
      <body>
        <div class = "container">
          <div class = "box">
            <img src= {imagemA} alt="lalala" />
          </div>
          <div class = "box">
            <img src= {imagemB} alt="lalala" />
          </div>
          <div class = "box">
            <img src= {imagemC} alt="lalala" />
          </div>
          <div class = "box">
            <img src= {imagemD} alt="lalala" />
          </div>
          <div class = "box">
            <img src= {imagemE} alt="lalala" />
          </div>

        </div>

        <div class= "autor"> 
          <p> Julia Peres Cardoso - 2DB </p>
        </div>

      </body>
    </>
  )
}

export default App
